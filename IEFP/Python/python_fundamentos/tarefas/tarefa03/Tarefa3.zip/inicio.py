import random

def greatings():
    msgBV = ["ola" , "boa tarde" , "bom dia" , "boa noite"]
    i = random.randrange(0 , len(msgBV))
    print(msgBV[i])

